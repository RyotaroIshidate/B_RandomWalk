#!/bin/sh
 jar cfm levywalk.jar Manifest.txt ./levywalk/

