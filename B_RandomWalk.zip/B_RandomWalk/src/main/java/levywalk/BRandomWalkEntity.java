package levywalk;

import java.lang.Math;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;
import java.util.Random;
import org.graphstream.algorithm.randomWalk.Entity;
import org.graphstream.algorithm.randomWalk.RandomWalk;
import org.graphstream.algorithm.randomWalk.TabuEntity;
import org.graphstream.algorithm.Toolkit;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Node;

import static java.lang.String.format;

public class BRandomWalkEntity extends TabuEntity
{
  final Double decimal = Double.valueOf(0.0000001);
  Double counter = Double.valueOf(0.0); // ナンバリング

  Random random = new Random();
  Boolean researchCoverRatio; 
  Double permissibleError; // 許容誤差
  Double lambda; // スケーリングパラメータ,ラムダ
  Boolean debug = false;

  @Override
    public void init(RandomWalk.Context context, Node start)
    {
      super.init(context, start);
      //System.out.println("RandomSeed: " + this.seed); // シードの確認
      start.addAttribute("start", "start");
      return;
    }

  @Override
    public void step()
    {
      BRandomWalkStep();
  
      return;
    }

  protected void BRandomWalkStep()
  {
    Integer hopLength = 1;
    Integer aValue = this.counter.intValue();            // 整数部はそのままで
    this.counter = Double.valueOf(aValue.doubleValue()); // 少数部を0にする
    this.counter += 1.0;    

    for(Integer i = 1; i <= hopLength; i++) // hopLength分のLevyWalkを繰り返す
    {
      ArrayList<Edge> neighbors = this.getNeighborEdge(this.current); // 隣接エッジを取得      

      ArrayList<Node> neighbors_node = this.getNeighborNode(this.current); //隣接ノードを取得

      ArrayList<Integer> neighbor_node_degree = this.getNodeDegree(neighbors_node); //隣接ノードの次数を取得
            
      // 移動可能なエッジの中からランダムにエッジを取得
      Edge neighbor = this.getRandomError(neighbors, neighbors_node, neighbor_node_degree);
      this.counter += this.decimal;
      current.addAttribute("counter", this.counter);
      this.cross(neighbor);
      
      if(!this.researchCoverRatio){ // カバー率を調べる場合 -> false
        if(this.current.hasAttribute("target")){
          return;
        }
      }
      System.out.printf("\r%3.0fsteps (lw %3.0f%%)", counter, i.doubleValue()/hopLength.doubleValue()*100.0);
    }

    return;
  }

  // シードを設定
  public void setRandomSeed(Long seed)
  {
    this.random.setSeed(seed);
    return;
  }

  //隣接エッジを取得
  public ArrayList<Edge> getNeighborEdge(Node aNode)
  {
    Iterator<? extends Edge> anEdge = aNode.getLeavingEdgeIterator();
    ArrayList<Edge> edges = new ArrayList<Edge>(0);
    while (anEdge.hasNext()) edges.add(anEdge.next()); // 隣接ノードを追加

    return edges;
  }

  //隣接ノードを取得
  public ArrayList<Node> getNeighborNode(Node aNode){
    Iterator<? extends Node> anNode = aNode.getNeighborNodeIterator();
    ArrayList<Node> nodes = new ArrayList<Node>(0);
    while (anNode.hasNext()) nodes.add(anNode.next());

    return nodes;
  }
 
  //ノードの次数を取得
  public ArrayList<Integer> getNodeDegree(ArrayList<Node> aNode){
    ArrayList<Integer> nodes = new ArrayList<Integer>(0);
    for(Node node : aNode){
      Integer node_degree = node.getDegree();
      nodes.add(node_degree);
    }
    return nodes;
  }

  // 遷移確率に基づいてランダムでエッジを取得
  public Edge getRandomError(ArrayList<Edge> anArray, ArrayList<Node> node, ArrayList<Integer> neighbor_node_degree)
  {
    Double beta = 0.5;   // ベータ
    Edge randomEdge = null;  // 初期化
    ArrayList<Double> degree = this.conversionDouble(neighbor_node_degree); // 隣接ノードの次数
    ArrayList<Double> probability = this.getProbability(degree, beta);      //遷移確率

    Double EdgeID = random.nextDouble();
    Double sumPro = 0.0;

    for(Integer i=0; i<probability.size(); i++){
      if(i < probability.size()-1){
        if(sumPro < EdgeID && EdgeID <= sumPro+probability.get(i)){
          randomEdge = this.current.getEdgeFrom(node.get(i));
          break;
        }
        sumPro += probability.get(i);
      } else {
        randomEdge = this.current.getEdgeFrom(node.get(i));
      }
    }
    return randomEdge;
  }

  //IntegerのArrayListをDoubleに変換
  public ArrayList<Double> conversionDouble(ArrayList<Integer> neighbor_node_degree){
    ArrayList<Double> degree = new ArrayList<Double>(0);

    for(Integer inte : neighbor_node_degree){
      degree.add((double)inte);
    }
    return degree;
  }

  //遷移確率を取得
  public ArrayList<Double> getProbability(ArrayList<Double> degree, Double beta){
    //分母
    Double denominator = 0.0;
    for(Double deg : degree){
      denominator += Math.pow(deg, -beta);
    }
    //分子
    ArrayList<Double> molecule = new ArrayList<Double>(0);
    for(Double deg : degree){
      molecule.add(Math.pow(deg, -beta));
    }
    //遷移確率
    ArrayList<Double> probability = new ArrayList<Double>(0);

    for(Double mol : molecule){
      probability.add(mol/denominator);
    }
    return probability;
  }

}


