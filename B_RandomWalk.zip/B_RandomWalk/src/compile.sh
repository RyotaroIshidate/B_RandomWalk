#!/bin/sh
javac -d ../classes/ -cp ../lib/commons-cli-1.4.jar:../lib/gs-ui-1.2.jar:../lib/gs-algo-1.2.jar:../lib/gs-core-1.2.jar ./main/java/levywalk/*.java

